unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ShellCtrls, ComCtrls,
  ExtCtrls, StdCtrls, strbox3,lazfileutils, SynHighlighterPas, SynEdit;

type
  TMyDataRec = record
        colo: Tcolor;
        boolio: Boolean;   // true for dir false for file
  end;
  type
  TSavedItem = record
    Caption: string;
    SubItems: TStringList;
    Data: Pointer;
  end;

type

  { TForm1 }

  TForm1 = class(TForm)
    Edit1: TEdit;
    Image1: TImage;
    Image2: TImage;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    ListView1: TListView;
    ListView2: TListView;
    Panel1: TPanel;
    Panel10: TPanel;
    Panel11: TPanel;
    Panel12: TPanel;
    Panel2: TPanel;
    Panel3: TPanel;
    Panel4: TPanel;
    Panel5: TPanel;
    Panel6: TPanel;
    Panel7: TPanel;
    Panel8: TPanel;
    Panel9: TPanel;
    pnlMkDir: TPanel;
    SynEdit1: TSynEdit;
    SynFreePascalSyn1: TSynFreePascalSyn;
    procedure FormCreate(Sender: TObject);
    procedure ListView1Click(Sender: TObject);
    procedure ListView1CustomDrawItem(Sender: TCustomListView; Item: TListItem;
      State: TCustomDrawState; var DefaultDraw: Boolean);
    procedure ListView2Click(Sender: TObject);
    procedure ListView2CustomDraw(Sender: TCustomListView; const ARect: TRect;
      var DefaultDraw: Boolean);
    procedure Panel10Click(Sender: TObject);
    procedure Panel12Click(Sender: TObject);
    procedure Panel1Click(Sender: TObject);
    procedure Panel4Click(Sender: TObject);
    procedure Panel9Click(Sender: TObject);

  private
     procedure PanelClick(Sender: TObject);

   procedure UpdateListView(sl: tstringlist;listviewX: tlistview);
    procedure CreateButtons;
    procedure CreateDirAndCopy;
    function GetOtherListview(listviewx: tlistview): tlistview;
    procedure ListviewProcess(listviewx: tlistview);
    procedure MakeAdirectory;
    procedure MoveAdirectoryAndFile;
  public

  end;

var
  Form1: TForm1;
   const
   baseFontSize = 14;

implementation

{$R *.lfm}

{ TForm1 }


procedure TForm1.FormCreate(Sender: TObject);
var
  sl: tstringlist;
  Node: TTreeNode;
  x,i: integer;
  s: string;
begin

 form1.left := 0;
 form1.top  := 0;
 form1.width := screen.width;
 form1.height := screen.height;
 form1.Font.Size := baseFontSize;
 if iswindowmanager('i3') then
    begin

   //  showmessage('i3 mode activated');
     for i := 0 to form1.ControlCount - 1 do
             begin
             if form1.Controls[i] is TPanel then
              Tpanel(form1.Controls[i]).Font.Size := 18;
                tpanel(form1.controls[i]).Height := tpanel(form1.controls[i]).Height +20;
             end;
    form1.font.size := basefontsize+8    ;
    listview1.font.size := basefontsize+4;
    listview2.font.size := basefontsize+4;
    panel5.width := (screen.width div 8)*4;
 panel7.width := (screen.width div 8)*2;
    end
    else
    begin

    panel5.width := (screen.width div 8)*3;
 panel7.width := (screen.width div 8)*2;
    end;


 synedit1.Font.Size := form1.font.size -4;

 label1.Caption := getcurrentdir;
 label2.caption := getcurrentdir;
 if fileexists('about.png') then
 image1.Picture.LoadFromFile('about.png');
 CreateButtons;

  sl := tstringlist.create;
   sl := DirectoryStringList(getcurrentdir);
   //sl.Sort;
   // Node := TreeView1.Items.Add(nil, '..Parent');
      for x := 0 to sl.count-1 do
  // for x := 0 to 10 do
     begin
     s := ExcludeTrailingPathDelimiter(sl[x]);
     s := getlasttoken(s,'/');

   //  treeview1.Items.Add(node,s);
     end;
  sl := DirsAndFilesStringList(getcurrentdir,false);

  updatelistview(sl,listview1);
   updatelistview(sl,listview2);
end;
procedure TForm1.MakeAdirectory;
begin

    panel8.Visible := true;
end;
function Tform1.GetOtherListview(listviewx: tlistview): tlistview;
begin
 if listviewx.Name = 'listview1' then
    begin
     result := listview2;

    end
    else
    result := listview1;
end;

procedure Tform1.MoveAdirectoryAndFile;
var
  sl,sl2: tstringlist;
  Item: TListItem;
  s,s2,fdStrD,fdStrS: string;
  x: integer;
  listviewx: tlistview;
begin
 s2 := 'nil';
 if listview1.Focused = true then
          begin
    listviewx := listview1;
    fdstrS := label1.Caption;
    fdStrD := label2.caption;
          end
    else
          begin
    listviewx := listview2;
     fdstrS := label2.caption;
     fdstrD := label1.caption;

          end;

 sl := tstringlist.Create;
 sl2 := tstringlist.create;
 // listviewX :=

// fdStrS :=
 try

                              begin
                                Item := ListViewx.Selected;
                                 if item <> nil then
                                 sl.add(item.caption);
                                     while Item <> nil do
                                           begin
                                           //listview1.GetNextItem();

                                            Item := ListViewx.GetNextItem(Item, sdAll, [lisSelected]);
                                            if item<> nil then
                                            sl.Add(item.Caption);
                                           end;

                              end;
   // showmessage(sl.Text);
   for x:= 0 to sl.Count -1 do
           begin
            s2 := sl[x];
            s := fdStrS +'/'+ sl[x];
           executersynccommand('mv -v ' + '''' + S + '''' + ' ' + '''' + fdStrD + '''',sl);
           end;
   finally
  sl.Free;
   end;

   sl2 :=  DirsAndFilesStringList(label1.caption,false);
                                   updatelistview(sl2,listview1);
   sl2 :=   DirsAndFilesStringList(label2.caption,false);
                                    updatelistview(sl2,listview2);

                                    sl2.Free;
                                    if s2 <> 'nil' then
                                    begin
                                     listviewx := getotherlistview(listviewx);
                                    Item := ListViewx.Items.FindCaption(0, s2, False, True, False);
                                    if Item <> nil then
                                       begin
                                         Item.Selected := True;
                                         Item.MakeVisible(False);
                                       end;

                                    end;

  // updatelistview(sl
end;

procedure TForm1.CreateDirAndCopy;
var
  fdStrS,fdStrD: string;
  sl: tstringlist;
begin
   if listview1.focused = true then
                              begin
    fdStrS  := label1.Caption+'/'+listview1.Selected.caption;
    fdStrD := label2.caption+'/'+listview1.selected.caption;
                              end;
                   if listview2.focused = true then
                              begin
    fdStrS  := label2.Caption+'/'+listview2.Selected.caption;
    fdStrD := label1.caption+'/'+listview2.selected.caption;
                              end;
     sl := tstringlist.Create;
     // ( are we copying a dir not a file )
                      // and check if we have it in the destination if not create it
    if not directoryexists(fdStrd) and directoryexists(fdStrS) then
              //  mkdir (fdstrd);
                forcedirectories(fdstrd);
      if  directoryexists(fdStrd) and directoryexists(fdStrS) then
              //  mkdir (fdstrd);
                 // use my date function is better than datetostr as pads 0 to
                 // numbers if less than 10 this makes listings work in alpha
                 // sorted directories
                 begin
                forcedirectories(fdstrD+'-'+gettodaysdate(0,'-')+timetostr(now));
                  fdstrD := fdstrD+'-'+gettodaysdate(0,'-')+timetostr(now);

                 end;
   sl := executersynccommand('cp -rv ' + '''' + fdStrS + '''' + ' ' + '''' + fdStrD + '''',sl);
  // sl := executersynccommand( 'cp -rv '  + fdStrS  + ' '  + fdStrD ,sl);
        // display files copied
       // showmessage(sl.Text);
       IF SL.Count > 0 THEN
                   begin
                                   if listview1.focused = true then
                              begin
                                   sl :=  DirsAndFilesStringList(label2.caption,false);
                                   updatelistview(sl,listview2);

                              end;
                                   if listview2.focused = true then
                              begin
                                   sl :=  DirsAndFilesStringList(label1.caption,false);
                                   updatelistview(sl,listview1);

                              end;
                  end;

end;

procedure TForm1.PanelClick(Sender: TObject);
var
  s,fdStrS,fdStrD: string;
  sl: tstringlist;
  x,oldsize: integer;
   //Ctrl: TWinControl;


begin


     sl := tstringlist.Create;
    s := tpanel(sender).caption;
     if s = 'Copy' then
                   CreateDirAndCopy;
     if s = 'Make Dir' then
                   MakeAdirectory;
      if s = 'Move' then
                   MoveAdirectoryAndFile;


    // check first to see if dest dir exists in the source
    // ( are we copying a dir not a file )
                      // and check if we have it in the destination if not create it
 {   if not directoryexists(fdStrd) and directoryexists(fdStrS) then
              //  mkdir (fdstrd);
                forcedirectories(fdstrd);

   sl := executersynccommand('cp -rv ' + '''' + fdStrS + '''' + ' ' + '''' + fdStrD + '''',sl);
  // sl := executersynccommand( 'cp -rv '  + fdStrS  + ' '  + fdStrD ,sl);
        // display files copied
       // showmessage(sl.Text);
       IF SL.Count > 0 THEN
                   begin
                                   sl :=  DirsAndFilesStringList(label2.caption,false);
                  updatelistview(sl,listview2);
                  end;

                  end;  }
  end;

procedure TForm1.CreateButtons;
var
  x:      integer;
  btnPnl:  tpanel;
  sl: tstringlist;
begin
   sl := tstringlist.Create;
   for x := 0 to 6 do
         begin
       if x = 6 then
      sl.Add('Archive');
     if x = 5 then
      sl.Add('Copy');
     if x = 4 then
      sl.Add('Move');
     if x = 3 then
      sl.Add('Make Dir');
     if x = 2 then
      sl.Add('Rename');
     if x = 1 then
      sl.Add('Delete');
      if x = 0 then
      sl.Add('Undo');

    //else
   // sl.Add('copy'+inttostr(x));
   //Process.CommandLine := 'cp -r ' + '''' + fdStrS + '''' + ' ' + '''' + fdStrD + '''';
         end;
   for x := 0 to sl.count-1 do
           begin

             btnPnl := tpanel.Create(form1.Panel3);
             if odd(x) then
              btnPnl.Color := clBlack;
             btnPnl.parent := form1.panel3;
             btnPnl.Caption := sl[x];
             btnPnl.Align   := alLeft;
             btnPnl.OnClick := @panelclick;
           end;
   sl.destroy;
end;

procedure TForm1.listviewprocess(listviewx: tlistview);
var
   Node: TTreeNode;
   sl: tstringlist  ;
   labelx: tlabel;
begin
   if listviewx.Name = 'ListView1' then
    labelx := label1
    else
    labelx := label2;
   chdir(labelx.caption);

   if listviewx.Selected.Caption = '..Parent' then
    begin
      sl := tstringlist.create;
          ////  chdir(labelx.caption);
      chdir(GetParentDir(getcurrentdir));
      labelx.Caption := getcurrentdir;
      sl := DirsAndFilesStringList(getcurrentdir,false);
      updatelistview(sl,listviewx);

      exit;
    end;
   if (tcolor(listviewx.Selected.Data) = clTeal) and
   fileisreadable(listviewx.Selected.caption) then   // it is a directory we have
                                                     // access to as regular user
         begin
           if labelx.Caption <> '/' then
        labelx.Caption := labelx.caption+'/'+listviewx.Selected.caption
        else
        labelx.Caption := '/'+listviewx.Selected.caption;
       sl := tstringlist.create;
       if directoryexists(getcurrentdir+'/'+listviewx.selected.caption) then
        chdir(getcurrentdir+'/'+listviewx.selected.caption)  else

    showmessage('Not found '+ getcurrentdir+'/'+listviewx.Selected.caption);

     sl := DirsAndFilesStringList(getcurrentdir,false);
   updatelistview(sl,listviewx);
   sl.destroy;
   exit;
   end;
   // are we clickingon a file (clMaroon) then show centre panel

   if (tcolor(listviewx.Selected.Data) = clMaroon)  then
   begin
     //text type files pascal, python, shell etc
   if (pos('.pas',listviewx.Selected.caption) <> 0 )
   or (pos('.lfm',listviewx.Selected.caption) <> 0 )
    or (pos('.md',listviewx.Selected.caption) <> 0 )
   or (pos('.txt',listviewx.Selected.caption) <> 0 )
   or (pos('.csv',listviewx.Selected.caption) <> 0 )
     or (pos('.ini',listviewx.Selected.caption) <> 0 )
   or (pos('.py',listviewx.Selected.caption) <> 0 )
   or (pos('.sh',listviewx.Selected.caption) <> 0 )
    or (pos('.lpr',listviewx.Selected.caption) <> 0 ) then
       begin
       synedit1.visible := true;
       panel7.visible := false;
      // image2.Visible := false;
      synedit1.Visible := true;
       synedit1.Lines.LoadFromFile(labelx.Caption+'/'+listviewx.Selected.caption);
       synedit1.font.color := clskyblue;
       end;
    if (pos('.png',listviewx.Selected.caption) <> 0 )
    or (pos('.jpg',listviewx.Selected.caption) <> 0 )
    or (pos('.jpeg',listviewx.Selected.caption) <> 0 )
     or (pos('.ico',listviewx.Selected.caption) <> 0 )
    or (pos('.bmp',listviewx.Selected.caption) <> 0 )
    or (pos('.gif',listviewx.Selected.caption) <> 0 )then
       begin
          synedit1.Visible := false;
          //image1.Visible := true;
          //image2.visible := true;
          panel7.Visible := true;
          image2.Picture.LoadFromFile(labelx.Caption+'/'+listviewx.selected.caption);
       end;
   end;

end;

procedure TForm1.ListView1Click(Sender: TObject);
begin
   listviewprocess(listview1);

end;

procedure TForm1.ListView1CustomDrawItem(Sender: TCustomListView;
  Item: TListItem; State: TCustomDrawState; var DefaultDraw: Boolean);
var
  rct: trect;
begin
    DefaultDraw := False;
    //sender.Font.size := 22;
   sender.canvas.Brush.Style := bsClear;
  if tcolor(item.data) = clMaroon then
        Sender.Canvas.brush.Color :=  clnavy;//$00431C43;
  if tcolor(item.data) = clTeal then
         Sender.Canvas.brush.Color := $001A361A;
     if item.caption = '..Parent' then
         Sender.Canvas.brush.Color := clBlack;
     rct := Item.DisplayRect(drBounds);


   Sender.Canvas.FillRect(rct);
  // Draw the caption text
  Sender.Canvas.Font.Color := clWhite;
  if iswindowmanager('i3') then
  sender.canvas.font.Size := basefontsize+8
  else
  sender.canvas.font.size := basefontsize-2;
  Sender.Canvas.TextOut(rct.Left + 2, rct.Top, Item.Caption);

end;

procedure TForm1.ListView2Click(Sender: TObject);

begin
    listviewprocess(listview2);

end;

procedure TForm1.ListView2CustomDraw(Sender: TCustomListView;
  const ARect: TRect; var DefaultDraw: Boolean);
begin
  Sender.Canvas.Font.Size := 18;
end;

procedure TForm1.Panel10Click(Sender: TObject);
begin
  pnlMkDir.Visible := false;
end;

procedure TForm1.Panel12Click(Sender: TObject);
begin
  panel7.visible := not panel7.visible;
  panel5.Width := screen.width div 2;
  panel6.width := screen.width div 2;
end;

procedure TForm1.Panel1Click(Sender: TObject);
begin
     application.terminate;
end;

procedure TForm1.Panel4Click(Sender: TObject);
begin
  application.terminate;
end;

procedure TForm1.Panel9Click(Sender: TObject);
begin

  forcedirectories(getcurrentdir+'/'+edit1.Text);
  if directoryexists(getcurrentdir+'/'+edit1.Text) then
     pnlMkdir.Visible := false
     else
     showmessage('Directory create failed');
end;


procedure TForm1.UpdateListView(sl: tstringlist;listviewX: tlistview);
var
    colo: tcolor;
    x: integer;
    s: string;
      Item: TListItem;

begin
      listviewx.items.Clear;
       Item := ListViewx.Items.Add;
       item.Caption := '..Parent';
                       for x := 0 to sl.count-1 do

                               begin
                               s := ExcludeTrailingPathDelimiter(sl[x]);
                               //// il := tstringlist.Create;
                               if sl[x] <> s then               begin
                                            //  s := uppercase(s) ;
                                               colo := clTeal;
                                                          end
                                                          else
                                                          colo := clMaroon;
                               s := getlasttoken(s,'/');
                              // listview1.Items.ad;


                              Item := ListViewx.Items.Add;

                              item.Data := pointer(colo); //keeps colors for
                                                          // directorys Teal
                                                          // files      Maroon
                             Item.Caption := s;
                              // listview1.Items.Add(s);
                               end;
end;






{ --- Handle ".." selection to navigate up --- }

//TTreeView(ShellTreeView1).OnAddition := @ShellTreeView1OnAddition;
end.

