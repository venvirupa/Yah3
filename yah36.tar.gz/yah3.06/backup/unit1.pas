unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ShellCtrls, ComCtrls,
  ExtCtrls, StdCtrls, Menus, strbox3,lazfileutils, SynHighlighterPas, SynEdit,
  LCLIntf;

type
  TMyDataRec = record
        colo: Tcolor;
        boolio: Boolean;   // true for dir false for file
  end;
  type
  TSavedItem = record
    Caption: string;
    SubItems: TStringList;
    Data: Pointer;
  end;

type

  { TForm1 }

  TForm1 = class(TForm)
    edtDirName: TEdit;
    Image1: TImage;
    Image2: TImage;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    lblDisplay: TLabel;
    ListView1: TListView;
    ListView2: TListView;
    MenuItem1: TMenuItem;
    Panel1: TPanel;
    Panel10: TPanel;
    Panel11: TPanel;
    pnlOpenImage: TPanel;
    pnlOpen: TPanel;
    pnlClose: TPanel;
    Panel2: TPanel;
    pnlInfo: TPanel;
    pnlExit: TPanel;
    pnlDisplay: TPanel;
    pnlLeftList: TPanel;
    pnlRightList: TPanel;
    Panel7: TPanel;
    Panel8: TPanel;
    Panel9: TPanel;
    pnlMkDir: TPanel;
    PopupMenu1: TPopupMenu;
    SynEdit1: TSynEdit;
    SynFreePascalSyn1: TSynFreePascalSyn;
    procedure FormCreate(Sender: TObject);
    procedure FormPaint(Sender: TObject);
    procedure ListView1Click(Sender: TObject);
    procedure ListView1CustomDrawItem(Sender: TCustomListView; Item: TListItem;
      State: TCustomDrawState; var DefaultDraw: Boolean);
    procedure ListView1SelectItem(Sender: TObject; Item: TListItem;
      Selected: Boolean);
    procedure ListView2Click(Sender: TObject);
    procedure ListView2CustomDraw(Sender: TCustomListView; const ARect: TRect;
      var DefaultDraw: Boolean);
    procedure MenuItem1Click(Sender: TObject);
    procedure Panel10Click(Sender: TObject);
    procedure pnlOpenClick(Sender: TObject);
    procedure pnlCloseClick(Sender: TObject);
    procedure Panel1Click(Sender: TObject);
    procedure pnlExitClick(Sender: TObject);
    procedure Panel9Click(Sender: TObject);

  private
     procedure PanelClick(Sender: TObject);
   procedure UpdateDisplayStats(listviewx: tlistview);
   procedure UpdateListView(sl: tstringlist;listviewX: tlistview);
   function   CopylistofFilesandDirs(fdstrS,fdstrD: string): tStringlist;
    procedure CreateButtons;
    procedure CreateDirAndCopy;
    procedure DeleteToTrash;
    function GetOtherListview(listviewx: tlistview): tlistview;
    function GetSelectedListview: tlistview;
    procedure ListviewProcess(listviewx: tlistview);
    procedure MakeAdirectory;
    procedure MoveAdirectoryAndFile;
    procedure MenuToolsShow;
    procedure SelectAllProcess;

  public

  end;

var
  Form1: TForm1;
   const
   baseFontSize = 14;
   baseFontSizei3 = 18;

implementation

{$R *.lfm}

{ TForm1 }


procedure TForm1.FormCreate(Sender: TObject);
var
  sl: tstringlist;
  Node: TTreeNode;
  x,i: integer;
  s: string;
begin

 form1.left := 0;
 form1.top  := 0;
 form1.width := screen.width;
 form1.height := screen.height;
 form1.Font.Size := baseFontSize;

 if iswindowmanager('i3') then
    begin
        //
   //    executeCmdDetach('lazbuild --build-mode=Release '+extractfilename(application.exename)+'.lpi',sl);

     for i := 0 to form1.ControlCount - 1 do
             begin
             if (form1.Controls[i] is TPanel) then
                                     begin
              Tpanel(form1.Controls[i]).Font.Size := basefontsize +8;
                tpanel(form1.controls[i]).Height := tpanel(form1.controls[i]).Height +20;
                tpanel(form1.controls[i]).width :=  tpanel(form1.controls[i]).width +100;
                                     end;
               if (form1.Controls[i] is TLabel) then
                                     begin
              TLabel(form1.Controls[i]).Font.Size := basefontsize +8;
                TLabel(form1.controls[i]).Height := TLabel(form1.controls[i]).Height +20;
                TLabel(form1.controls[i]).width :=  TLabel(form1.controls[i]).width +100;
                                     end;
             end;
    form1.font.size := basefontsize+8    ;
    listview1.font.size := basefontsize+4;
    listview2.font.size := basefontsize+4;
    pnlLeftList.width := (screen.width div 8)*5;
     pnlDisplay.Font.size := basefontsize +4;
     pnlDisplay.width := screen.width div 2;
     pnlDisplay.height := screen.height div 3 ;
 pnlRightList.width := (screen.width div 8 )*5 ;
  panel7.width := (screen.width div 8)*2;
    end
    else
    begin
     pnlDisplay.Font.size := basefontsize -4;
     pnlDisplay.width :=  (screen.width div 32)*9;

    pnlLeftList.width := (screen.width div 8)*3;
 panel7.width := (screen.width div 8)*2;
    end;

 synedit1.Font.Size := form1.font.size -4;

 label1.Caption := getcurrentdir;
 label2.caption := getcurrentdir;

 CreateButtons;

  sl := tstringlist.create;
   sl := DirectoryStringList(getcurrentdir);
   //sl.Sort;
   // Node := TreeView1.Items.Add(nil, '..Parent');
      for x := 0 to sl.count-1 do
  // for x := 0 to 10 do
     begin
     s := ExcludeTrailingPathDelimiter(sl[x]);
     s := getlasttoken(s,'/');

   //  treeview1.Items.Add(node,s);
     end;
  sl := DirsAndFilesStringList(getcurrentdir,false);

  updatelistview(sl,listview1);
   updatelistview(sl,listview2);
   pnlDisplay.Top := pnlInfo.height*2;

    pnlDisplay.left := pnlleftList.width;
  // pnlDisplay.width := screen.width div 4;
  // if
   //pnlDisplay.Font.size := basefontsize -4;
   updateDisplayStats(listview1);

end;

procedure TForm1.FormPaint(Sender: TObject);
var
  b: TBrush;
  rc: TRect;
  begin
b := TBrush.Create;
 try
   // Ensure ImgBrush contains the bitmap you want to tile
   // use a Timage to store the bitmap so there is no
   // loading at run time in system startup on linux mint
   // as this causes errors
   b.Bitmap := image1.Picture.Bitmap;

   // Set the form's canvas brush to your tiled brush
   Canvas.Brush := b;

   // Define the rectangle covering the entire form
   rc := Rect(0, 0, Self.Width, Self.Height);

   // Fill the form with the tiled pattern
   if sender.ClassName = 'TForm1' then
   tform(sender).Canvas.FillRect(rc)
    else

   tpanel(sender).canvas.FillRect(rc)   ;

 finally
   b.Free;

 end;

end;
function Tform1.GetSelectedListview: tlistview;
begin
    if listview1.Focused then
       result := listview1
       else
       result := listview2;
end;

procedure TForm1.UpdateDisplayStats(listviewx: tlistview);
begin
 if listviewx.name = 'ListView1' then
     lblDisplay.caption := 'Currently focused directory stats (Left) '+#13+label1.Caption+#13+' Items in directory '+inttostr(listviewx.Items.count-1)
     else
     lblDisplay.caption :='Currently focused directory stats (Right) '+#13+label2.Caption+#13+' Items in directory '+inttostr(listviewx.Items.count-1);

end;

procedure TForm1.MakeAdirectory;
begin
    synedit1.Visible := false;
    pnlMkdir.Visible := true;
    panel7.Visible := true;
    panel8.Visible := true;

end;
function Tform1.GetOtherListview(listviewx: tlistview): tlistview;
begin
 if listviewx.Name = 'listview1' then
    begin
     result := listview2;

    end
    else
    result := listview1;
end;

procedure Tform1.MoveAdirectoryAndFile;
var
  sl,sl2: tstringlist;
  Item: TListItem;
  s,s2,fdStrD,fdStrS: string;
  x: integer;
  listviewx: tlistview;
begin
 s2 := 'nil';
 if listview1.Focused = true then
          begin
    listviewx := listview1;
    fdstrS := label1.Caption;
    fdStrD := label2.caption;
          end
    else
          begin
    listviewx := listview2;
     fdstrS := label2.caption;
     fdstrD := label1.caption;

          end;

 sl := tstringlist.Create;
 sl2 := tstringlist.create;
 // listviewX :=

// fdStrS :=
 try

                              begin
                                Item := ListViewx.Selected;
                                 if item <> nil then
                                 sl.add(item.caption);
                                     while Item <> nil do
                                           begin
                                           //listview1.GetNextItem();

                                            Item := ListViewx.GetNextItem(Item, sdAll, [lisSelected]);
                                            if item<> nil then
                                            sl.Add(item.Caption);
                                           end;

                              end;
   // showmessage(sl.Text);
   for x:= 0 to sl.Count -1 do
           begin
            s2 := sl[x];
            s := fdStrS +'/'+ sl[x];
           executersynccommand('mv -v ' + '''' + S + '''' + ' ' + '''' + fdStrD + '''',sl);
           end;
   finally
  sl.Free;
   end;

   sl2 :=  DirsAndFilesStringList(label1.caption,false);
                                   updatelistview(sl2,listview1);
   sl2 :=   DirsAndFilesStringList(label2.caption,false);
                                    updatelistview(sl2,listview2);

                                    sl2.Free;
                                    if s2 <> 'nil' then
                                    begin
                                     listviewx := getotherlistview(listviewx);
                                    Item := ListViewx.Items.FindCaption(0, s2, False, True, False);
                                    if Item <> nil then
                                       begin
                                         Item.Selected := True;
                                         Item.MakeVisible(False);
                                       end;

                                    end;

  // updatelistview(sl
end;
function TForm1.CopylistofFilesandDirs(fdstrS,fdstrD: string): tStringlist;
var
  sl: tstringlist;
  s,d: string;
begin
    sl := tstringlist.create;
    if directoryexists(fdstrS) then
    sl := executersynccommand('cp -rv ' + '''' + fdStrS + '''' + ' ' + '''' + fdStrD + '''',sl)
    else
    begin

     if not fileexists(fdstrD) then //+getlasttoken(fdstrS,'/')) then
    sl := executersynccommand('cp -v ' + '''' + fdStrS + '''' + ' ' + '''' + fdStrD + '''',sl)
       else
       begin
        s:= getlasttoken(fdstrS,'/');
        s:= getcopyname(s);
        d:= extractfilepath(fdStrD)+s;
      // fdstrD := getlasttoken;
     sl := executersynccommand('cp -v ' + '''' + fdStrS + '''' + ' ' + '''' + d + '''',sl);

       end;
    end;
    result := sl;
end;

procedure TForm1.CreateDirAndCopy;
var
  fdStrS,fdStrD: string;
  sl: tstringlist;
begin
   if listview1.focused = true then
                              begin
    fdStrS  := label1.Caption+'/'+listview1.Selected.caption;
    fdStrD := label2.caption+'/'+listview1.selected.caption;
                              end;
                   if listview2.focused = true then
                              begin
    fdStrS  := label2.Caption+'/'+listview2.Selected.caption;
    fdStrD := label1.caption+'/'+listview2.selected.caption;
                              end;
     sl := tstringlist.Create;
     // ( are we copying a dir not a file )
                      // and check if we have it in the destination if not create it
    if not directoryexists(fdStrd) and directoryexists(fdStrS) then
              //  mkdir (fdstrd);
                forcedirectories(fdstrd);
      if  directoryexists(fdStrd) and directoryexists(fdStrS) then
              //  mkdir (fdstrd);
                 // use my date function is better than datetostr as pads 0 to
                 // numbers if less than 10 this makes listings work in alpha
                 // sorted directories
                 begin
                forcedirectories(fdstrD+'-'+gettodaysdate(0,'-')+timetostr(now));
                  fdstrD := fdstrD+'-'+gettodaysdate(0,'-')+timetostr(now);

                 end;
   sl :=  CopylistofFilesandDirs(fdstrS,fdstrD);
  //// sl := executersynccommand('cp -rv ' + '''' + fdStrS + '''' + ' ' + '''' + fdStrD + '''',sl);
  // sl := executersynccommand( 'cp -rv '  + fdStrS  + ' '  + fdStrD ,sl);
        // display files copied
       // showmessage(sl.Text);
       IF SL.Count > 0 THEN
                   begin
                                   if listview1.focused = true then
                              begin
                                   sl :=  DirsAndFilesStringList(label2.caption,false);
                                   updatelistview(sl,listview2);

                              end;
                                   if listview2.focused = true then
                              begin
                                   sl :=  DirsAndFilesStringList(label1.caption,false);
                                   updatelistview(sl,listview1);

                              end;
                  end;

end;
procedure Tform1.MenuToolsShow;
var
  sl: tstringlist   ;
begin
 popupmenu1.PopUp(panel2.width,pnlInfo.height);

end;
procedure Tform1.SelectAllProcess;
var
  listviewx: tlistview;
begin
 listviewx := GetSelectedListview;
 listviewx.SelectAll;

end;
procedure TForm1.DeleteToTrash;
var
  listviewx: tlistview;
  sl:      tstringlist;
  s: string;
begin
 if not executeExists('trash-put') then
             begin
              showmessage('Need to install Trash-Cli for this command to work.'+#13+
              ' On the terminal do <sudo apt install trash-cli>'+#13+
              ' ( remove brakets ) to use these delete and undo functions.');
             end;
  sl := tstringlist.create;
  listviewx := GetSelectedListview;
  s:=  getcurrentdir+'/'+listviewx.selected.caption;
   sl := executersynccommand('trash-put '+''''+s+'''',sl);
    //use sl here to display results of delete
    showmessage(sl.text);
    sl := DirsAndFilesStringList(getcurrentdir,false);
    UpdateListView(sl,listviewX);
     sl.Free;
end;

procedure TForm1.PanelClick(Sender: TObject);
var
  s,fdStrS,fdStrD: string;
  sl: tstringlist;
  x,oldsize: integer;
   //Ctrl: TWinControl;


begin


     sl := tstringlist.Create;    // just create this here to remind me
                                  // to do feed back from commands
    s := tpanel(sender).caption;
     if s = 'Copy' then
                   CreateDirAndCopy;
     if s = 'Make Dir' then
                   MakeAdirectory;
      if s = 'Move' then
                   MoveAdirectoryAndFile;
       if s = 'Menu' then
                   MenuToolsShow;
       if s = 'Select All'    then
                   SelectAllprocess;
       if s = 'Delete' then
                   DeleteToTrash; // trash-cli can be installed with apt-get
                                  // install trash-cli
    // check first to see if dest dir exists in the source
    // ( are we copying a dir not a file )
                      // and check if we have it in the destination if not create it
 {   if not directoryexists(fdStrd) and directoryexists(fdStrS) then
              //  mkdir (fdstrd);
                forcedirectories(fdstrd);

   sl := executersynccommand('cp -rv ' + '''' + fdStrS + '''' + ' ' + '''' + fdStrD + '''',sl);
  // sl := executersynccommand( 'cp -rv '  + fdStrS  + ' '  + fdStrD ,sl);
        // display files copied
       // showmessage(sl.Text);
       IF SL.Count > 0 THEN
                   begin
                                   sl :=  DirsAndFilesStringList(label2.caption,false);
                  updatelistview(sl,listview2);
                  end;

                  end;  }
  end;

procedure TForm1.CreateButtons;
var
  x:      integer;
  btnPnl:  tpanel;
  sl: tstringlist;
begin
   sl := tstringlist.Create;
   for x := 0 to 7 do
         begin
         if x = 7 then
         sl.Add('Menu');
       if x = 6 then
      sl.Add('Archive');
     if x = 5 then
      sl.Add('Copy');
     if x = 4 then
      sl.Add('Move');
     if x = 3 then
      sl.Add('Make Dir');
     if x = 2 then
      sl.Add('Rename');
     if x = 1 then
      sl.Add('Delete');
      if x = 0 then
      sl.Add('Select All');

    //else
   // sl.Add('copy'+inttostr(x));
   //Process.CommandLine := 'cp -r ' + '''' + fdStrS + '''' + ' ' + '''' + fdStrD + '''';
         end;
   for x := 0 to sl.count-1 do
           begin

             btnPnl := tpanel.Create(form1.PnlInfo);
             if odd(x) then
              btnPnl.Color := clBlack;
             btnPnl.parent := form1.pnlInfo;
             btnPnl.Caption := sl[x];
             btnPnl.Align   := alLeft;
             if iswindowmanager('i3') then
             btnPnl.Width := btnPnl.width + 100;  // give extra width
                                                 // default too small
             btnPnl.OnClick := @panelclick;
           end;
   sl.destroy;
end;

procedure TForm1.listviewprocess(listviewx: tlistview);
var
   Node: TTreeNode;
   sl: tstringlist  ;
   labelx: tlabel;
   s: string;
begin

   if listviewx.Name = 'ListView1' then
    labelx := label1
    else
    labelx := label2;
   if  dirpathexists(labelx.Caption) then
            begin
             // try another check
      if directoryexists(labelx.Caption) then
   chdir(labelx.caption);

            end
   else
   begin
   showmessage('Dir not readable ( is a file? ) or access is restricted.');
   exit;
   end;
   if listviewx.Selected.Caption = '..Parent' then
    begin
      sl := tstringlist.create;
          ////  chdir(labelx.caption);
      chdir(GetParentDir(getcurrentdir));
      labelx.Caption := getcurrentdir;
      sl := DirsAndFilesStringList(getcurrentdir,false);
      updatelistview(sl,listviewx);

      exit;
    end;
   if (tcolor(listviewx.Selected.Data) = clTeal) and
   fileisreadable(listviewx.Selected.caption) then   // it is a directory we have
                                                     // access to as regular user
         begin
           if labelx.Caption <> '/' then
        labelx.Caption := labelx.caption+'/'+listviewx.Selected.caption
        else
        labelx.Caption := '/'+listviewx.Selected.caption;
       sl := tstringlist.create;
       if directoryexists(getcurrentdir+'/'+listviewx.selected.caption) then
        chdir(getcurrentdir+'/'+listviewx.selected.caption)  else
                begin
               labelx.Caption := getcurrentdir;

    showmessage('Not found '+ getcurrentdir+'/'+listviewx.Selected.caption);
                 end;
     sl := DirsAndFilesStringList(getcurrentdir,false);
   updatelistview(sl,listviewx);
   sl.destroy;
   exit;
   end;
   // are we clickingon a file (clMaroon) then show centre panel

   if (tcolor(listviewx.Selected.Data) = clMaroon)  then
   begin
     //text type files pascal, python, shell etc
    s:= lowercase(listviewx.selected.Caption);
   if (pos('.pas',s) <> 0 )
       or (pos('makefile',s) <> 0 )
   or (pos('.lfm',s) <> 0 )
    or (pos('.md',s) <> 0 )
   or (pos('.txt',s) <> 0 )
   or (pos('.csv',s) <> 0 )
     or (pos('.ini',s) <> 0 )
   or (pos('.py',s) <> 0 )
   or (pos('.sh',s) <> 0 )
    or (pos('.lpr',s) <> 0 ) then
       begin
       synedit1.visible := true;
       synedit1.Left := listview1.width;
       synedit1.top  := pnlDisplay.Height+(pnlInfo.height*2);
       synedit1.Width := pnlDisplay.Width;
       synedit1.Height := screen.Height - pnlDisplay.height-(pnlInfo.Height*2);
       panel7.visible := false;
      // image2.Visible := false;
      synedit1.Visible := true;
       synedit1.Lines.LoadFromFile(labelx.Caption+'/'+listviewx.Selected.caption);
       synedit1.font.color := clskyblue;
       end;
    if (pos('.png',s) <> 0 )
    or (pos('.jpg',s) <> 0 )
    or (pos('.jpeg',s) <> 0 )
     or (pos('.ico',s) <> 0 )
    or (pos('.bmp',s) <> 0 )
    or (pos('.gif',s) <> 0 )then
       begin
          synedit1.Visible := false;
          //image1.Visible := true;
          image2.width := pnlDisplay.Width;
          image2.visible := true;
          image2.Top := screen.Height div 3;
          image2.height := screen.Height div 2;
          image2.Stretch := true;
          panel7.Visible := true;
          image2.Picture.LoadFromFile(labelx.Caption+'/'+listviewx.selected.caption);
       end;
   end;

end;

procedure TForm1.ListView1Click(Sender: TObject);
begin
  synedit1.Visible := false;
  image2.Visible := false;
  panel7.visible := false;
   listviewprocess(listview1);
     UpdateDisplayStats(listview1);
end;

procedure TForm1.ListView1CustomDrawItem(Sender: TCustomListView;
  Item: TListItem; State: TCustomDrawState; var DefaultDraw: Boolean);
var
  rct: trect;
begin
    DefaultDraw := False;
    //sender.Font.size := 22;
   sender.canvas.Brush.Style := bsClear;
  if tcolor(item.data) = clMaroon then
        Sender.Canvas.brush.Color :=  clnavy;//$00431C43;
  if tcolor(item.data) = clTeal then
         Sender.Canvas.brush.Color := $001A361A;
     if item.caption = '..Parent' then
         Sender.Canvas.brush.Color := clBlack;
     rct := Item.DisplayRect(drBounds);


   Sender.Canvas.FillRect(rct);
  // Draw the caption text
  //Sender.Canvas.Font.Color := clWhite;
  if iswindowmanager('i3') then
  sender.canvas.font.Size := basefontsize+8
  else
  sender.canvas.font.size := basefontsize-2;
  if not odd(item.index) then
   Sender.Canvas.Font.Color := clWhite
   else
   sender.canvas.font.color := cllime;
  Sender.Canvas.TextOut(rct.Left + 2, rct.Top, Item.Caption);

end;

procedure TForm1.ListView1SelectItem(Sender: TObject; Item: TListItem;
  Selected: Boolean);
begin
  pnlOpen.Enabled := (ListView1.SelCount > 0) or (ListView2.SelCount > 0);
  // showmessage(inttostr(listview1.SelCount));
end;

procedure TForm1.ListView2Click(Sender: TObject);

begin
   synedit1.Visible := false;
  image2.Visible := false;
  panel7.visible := false;
    listviewprocess(listview2);
    UpdateDisplayStats(listview2);
end;

procedure TForm1.ListView2CustomDraw(Sender: TCustomListView;
  const ARect: TRect; var DefaultDraw: Boolean);
begin
  Sender.Canvas.Font.Size := 18;
end;

procedure TForm1.MenuItem1Click(Sender: TObject);
var
  sl: tstringlist;
begin
//show
//popupmenu1.PopUp(0,0);
  sl := tstringlist.Create;
  executeCmdDetach('lazbuild --build-mode=Release '+extractfilename(application.exename)+'.lpi',sl);

end;

procedure TForm1.Panel10Click(Sender: TObject);
begin
  pnlMkDir.Visible := false;
end;

procedure TForm1.pnlOpenClick(Sender: TObject);
var
  listviewx: Tlistview;
begin
 listviewx := getSelectedListview;
 if ListViewx.SelCount > 0 then
   OpenDocument(getcurrentdir+'/'+listviewx.selected.caption)
   else
   showmessage('No files selected.');
end;

procedure TForm1.pnlCloseClick(Sender: TObject);
begin
  panel7.visible := not panel7.visible;
 { pnlLeftList.Width := screen.width div 2;
  pnlRightList.width := screen.width div 2;  }
end;

procedure TForm1.Panel1Click(Sender: TObject);
begin
     application.terminate;
end;

procedure TForm1.pnlExitClick(Sender: TObject);
begin
  application.terminate;
end;

procedure TForm1.Panel9Click(Sender: TObject);
begin

  forcedirectories(getcurrentdir+'/'+edtDirName.Text);
  if directoryexists(getcurrentdir+'/'+edtDirName.Text) then
     pnlMkdir.Visible := false
     else
     showmessage('Directory create failed, maybe write permission?');
end;


procedure TForm1.UpdateListView(sl: tstringlist;listviewX: tlistview);
var
    colo: tcolor;
    x: integer;
    s,s2: string;
      Item: TListItem;

begin
      listviewx.items.Clear;
       Item := ListViewx.Items.Add;
       item.Caption := '..Parent';
                       for x := 0 to sl.count-1 do

                               begin
                               s := ExcludeTrailingPathDelimiter(sl[x]);
                               //// il := tstringlist.Create;
                               s2 := getlasttoken(s,'/');
                               if (sl[x] <> s)  then
                                               begin
                                                // or (s2[1] = '.')
                                            //  s := uppercase(s) ;
                                               colo := clTeal;
                                                          end
                                                          else
                                                          colo := clMaroon;
                               s := getlasttoken(s,'/');
                              // listview1.Items.ad;
                              { if odd(x) then
                                  listviewx.Canvas.font.Color := clred
                                  else
                                  listviewx.canvas.font.color := clwhite; }

                              Item := ListViewx.Items.Add;

                              item.Data := pointer(colo); //keeps colors for
                                                          // directorys Teal
                                                           // files      Maroon
                             Item.Caption := s;
                              // listview1.Items.Add(s);
                               end;
                       UpdateDisplayStats(listviewx);
end;






{ --- Handle ".." selection to navigate up --- }

//TTreeView(ShellTreeView1).OnAddition := @ShellTreeView1OnAddition;
end.

